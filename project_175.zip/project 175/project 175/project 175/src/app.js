const express = require('express');
const cors = require('cors');

// Import routes
const authRoutes = require('./modules/auth/auth.routes');
const categoryRoutes = require('./modules/categories/category.routes');
const courseRoutes = require('./modules/courses/course.routes');

const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// Mount Routes with /api prefix
app.use('/api/auth', authRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/courses', courseRoutes);

// Base Route
app.get('/', (req, res) => {
  res.status(200).json({ message: "Welcome to Course API!" });
});

// 404 Route Not Found Handler (Required for Screenshot 5)
app.use((req, res) => {
  res.status(404).json({ message: "Route Not Found" });
});

module.exports = app;