// In-memory categories array
let categories = [];

// Get all categories (200 OK)
exports.getAllCategories = (req, res) => {
  res.status(200).json(categories);
};

// Get category by ID (200 OK or 404 Not Found)
exports.getCategoryById = (req, res) => {
  const categoryId = parseInt(req.params.id);
  const category = categories.find(c => c.id === categoryId);

  if (!category) {
    return res.status(404).json({ message: 'Category not found' });
  }

  res.status(200).json(category);
};

// Create a category (201 Created or 400 Bad Request)
exports.createCategory = (req, res) => {
  const { name, description } = req.body;

  if (!name) {
    return res.status(400).json({ message: 'Category name is required' });
  }

  const newCategory = {
    id: categories.length + 1,
    name,
    description: description || ''
  };

  categories.push(newCategory);
  res.status(201).json(newCategory);
};

// Update a category (200 OK or 404 Not Found)
exports.updateCategory = (req, res) => {
  const categoryId = parseInt(req.params.id);
  const category = categories.find(c => c.id === categoryId);

  if (!category) {
    return res.status(404).json({ message: 'Category not found' });
  }

  const { name, description } = req.body;
  if (name) category.name = name;
  if (description) category.description = description;

  res.status(200).json(category);
};

// Delete a category (200 OK or 404 Not Found)
exports.deleteCategory = (req, res) => {
  const categoryId = parseInt(req.params.id);
  const index = categories.findIndex(c => c.id === categoryId);

  if (index === -1) {
    return res.status(404).json({ message: 'Category not found' });
  }

  const deleted = categories.splice(index, 1);
  res.status(200).json({ message: 'Category deleted successfully', deleted: deleted[0] });
};