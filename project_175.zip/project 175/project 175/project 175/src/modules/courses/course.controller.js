// In-memory courses array
let courses = [];

// Get all courses (200 OK)
exports.getAllCourses = (req, res) => {
  res.status(200).json(courses);
};

// Get course by ID (200 OK or 404 Not Found)
exports.getCourseById = (req, res) => {
  const courseId = parseInt(req.params.id);
  const course = courses.find(c => c.id === courseId);

  if (!course) {
    return res.status(404).json({ message: 'Course not found' });
  }

  res.status(200).json(course);
};

// Create a course (201 Created or 400 Bad Request)
exports.createCourse = (req, res) => {
  const { title, description, categoryId, price } = req.body;

  if (!title || !categoryId) {
    return res.status(400).json({ message: 'Course title and categoryId are required' });
  }

  const newCourse = {
    id: courses.length + 1,
    title,
    description: description || '',
    categoryId: parseInt(categoryId),
    price: price || 0
  };

  courses.push(newCourse);
  res.status(201).json(newCourse);
};

// Update a course (200 OK or 404 Not Found)
exports.updateCourse = (req, res) => {
  const courseId = parseInt(req.params.id);
  const course = courses.find(c => c.id === courseId);

  if (!course) {
    return res.status(404).json({ message: 'Course not found' });
  }

  const { title, description, categoryId, price } = req.body;
  if (title) course.title = title;
  if (description) course.description = description;
  if (categoryId) course.categoryId = parseInt(categoryId);
  if (price !== undefined) course.price = price;

  res.status(200).json(course);
};

// Delete a course (200 OK or 404 Not Found)
exports.deleteCourse = (req, res) => {
  const courseId = parseInt(req.params.id);
  const index = courses.findIndex(c => c.id === courseId);

  if (index === -1) {
    return res.status(404).json({ message: 'Course not found' });
  }

  const deleted = courses.splice(index, 1);
  res.status(200).json({ message: 'Course deleted successfully', deleted: deleted[0] });
};